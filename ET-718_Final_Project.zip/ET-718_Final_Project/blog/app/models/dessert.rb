class Dessert < ActiveRecord::Base
end
