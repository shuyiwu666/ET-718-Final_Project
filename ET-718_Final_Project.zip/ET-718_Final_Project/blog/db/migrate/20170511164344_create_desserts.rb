class CreateDesserts < ActiveRecord::Migration
  def change
    create_table :desserts do |t|
      t.string :title
      t.text :description
      t.string :flavor
      t.string :price
      t.string :videoURL

      t.timestamps
    end
  end
end
