require 'test_helper'

class DessertTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
