require 'test_helper'

class DessertsHelperTest < ActionView::TestCase
end
